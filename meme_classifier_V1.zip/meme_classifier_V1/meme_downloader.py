# Jeffrey Worley 
# 2021
# jeff@theworleys.com

import csv
import os
import subprocess
import random

IMAGES_FOLDER = "meme_img_set/"
TEST_FOLDER = "test/"
TRAIN_FOLDER = "train/"
CSV_FILE_NAME = "memes.csv"

# setup folders for test set and validation set
if not os.path.exists(IMAGES_FOLDER):
	os.mkdir(IMAGES_FOLDER)
os.chdir(IMAGES_FOLDER)
if not os.path.exists(TEST_FOLDER):
	os.mkdir(TEST_FOLDER)
if not os.path.exists(TRAIN_FOLDER):
	os.mkdir(TRAIN_FOLDER)
os.chdir("../")

# load csv file with scraped links
curlLinks = {}
with open(CSV_FILE_NAME) as csvFile:
	scrapedMemes = csv.reader(csvFile)
	next(scrapedMemes)
	if not scrapedMemes is None:
		for line in scrapedMemes:
			if not line[0] in curlLinks:
				curlLinks[line[0]] = []
			curlLinks[line[0]].append(line[2])
	else:
		print("Error: " + CSV_FILE_NAME + " file not found")

# curl images and randomly assign 20% to test and 80% to validation
for label in curlLinks:
	print("starting download for " + label)
	labelFolder = label + "/"
	currTestPath = IMAGES_FOLDER + TEST_FOLDER + labelFolder
	currTrainPath = IMAGES_FOLDER + TRAIN_FOLDER + labelFolder

	if not os.path.exists(currTestPath):
		os.mkdir(currTestPath)
	if not os.path.exists(currTrainPath):
		os.mkdir(currTrainPath)

	for imgLink in curlLinks[label]:
		imgName = label + "_" + imgLink.split("/")[1]
		if not os.path.exists(currTestPath + imgName) and not os.path.exists(currTrainPath + imgName):
			# only download images we dont already have 
			if random.random() < .2:
				# put in test folder

				subprocess.Popen("curl " + imgLink +  " > " + currTestPath + imgName, shell=True).wait()
			else:
				# put in val folder
				subprocess.Popen("curl " + imgLink +  " > " + currTrainPath + imgName, shell=True).wait()
	print("finished download for " + label)



